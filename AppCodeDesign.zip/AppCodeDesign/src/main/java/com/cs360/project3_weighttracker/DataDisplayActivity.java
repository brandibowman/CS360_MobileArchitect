package com.cs360.project3_weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DataDisplayActivity extends AppCompatActivity {

    private TableLayout weightTable;
    private Button addWeightButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_screen);

        // Initialize UI components
        weightTable = findViewById(R.id.weightTable);
        addWeightButton = findViewById(R.id.addWeightButton);
        dbHelper = new DatabaseHelper(this);

        // Get current user
        String currentUser = SharedPrefsUtils.getCurrentUser(this);
        if (currentUser == null) {
            Toast.makeText(this, "No user logged in. Redirecting to login.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // Display user-specific weight entries
        displayWeightEntries(currentUser);

        // Setup bottom navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_history);
        NavigationUtils.setupBottomNavigation(bottomNavigationView, this);

        // Add weight button functionality
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, RecordWeightActivity.class);
            startActivity(intent);
        });
    }

    private void displayWeightEntries(String currentUser) {
        weightTable.removeAllViews(); // Clear the table for fresh display

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_WEIGHTS,
                null,
                DatabaseHelper.COLUMN_USERNAME + " = ?", // Filter by the current user
                new String[]{currentUser},
                null,
                null,
                null
        );

        // Add header row
        TableRow headerRow = new TableRow(this);
        addTextToRow(headerRow, "Date");
        addTextToRow(headerRow, "Weight");
        addTextToRow(headerRow, "Actions");
        weightTable.addView(headerRow);

        // Add rows from the database
        while (cursor.moveToNext()) {
            TableRow row = new TableRow(this);

            String id = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
            String weight = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT));

            addTextToRow(row, date);
            addTextToRow(row, weight);

            // delete button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.secondary_light_purple));
            deleteButton.setOnClickListener(v -> {
                deleteWeightEntry(id);
                displayWeightEntries(currentUser); // Refresh the table after deletion
            });
            row.addView(deleteButton);

            weightTable.addView(row);
        }
        cursor.close(); // Close the cursor to avoid memory leaks
    }

    private void addTextToRow(TableRow row, String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        row.addView(textView);
    }

    private void deleteWeightEntry(String id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_WEIGHTS, DatabaseHelper.COLUMN_WEIGHT_ID + " = ?", new String[]{id});
        Toast.makeText(this, "Entry deleted.", Toast.LENGTH_SHORT).show();
    }
}
