package com.cs360.project3_weighttracker;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;

public class GoalChecker {

    public static void checkAndNotify(Context context, double currentWeight) {
        // Get the logged in user
        String currentUser = SharedPrefsUtils.getCurrentUser(context);
        if (currentUser == null) {
            Toast.makeText(context, "No user logged in. Notification skipped.", Toast.LENGTH_SHORT).show();
            return; // Exits if no user logged in
        }

        // Grabs user-specific data
        String goalWeightStr = SharedPrefsUtils.getUserData(context, currentUser, "goalWeight");
        String phoneNumber = SharedPrefsUtils.getUserData(context, currentUser, "phoneNumber");
        String goalType = SharedPrefsUtils.getUserData(context, currentUser, "goalType");
        String bufferZoneStr = SharedPrefsUtils.getUserData(context, currentUser, "bufferZone");

        if (goalWeightStr == null || goalWeightStr.isEmpty() || goalType == null || goalType.isEmpty()) {
            Toast.makeText(context, "Goal weight or type not set.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(context, "Phone number not set. Notification skipped.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // parses the goal weight from the stored data
            double goalWeight = Double.parseDouble(goalWeightStr);

            // Notify for weight loss
            if ("Weight Loss".equals(goalType) && currentWeight <= goalWeight) {
                sendSMS(context, phoneNumber, "Congratulations! You've reached your weight-loss goal of " + goalWeight + " lbs!");
            }
            // Notify for weight gain
            else if ("Weight Gain".equals(goalType) && currentWeight >= goalWeight) {
                sendSMS(context, phoneNumber, "Great job! You've reached your weight-gain goal of " + goalWeight + " lbs!");
            }
            // notify for outside buffer zone of maintaining weight
            else if ("Maintain Weight".equals(goalType) && bufferZoneStr != null && !bufferZoneStr.isEmpty()) {
                double bufferZone = Double.parseDouble(bufferZoneStr);
                double lowerBound = goalWeight - bufferZone;
                double upperBound = goalWeight + bufferZone;

                if (currentWeight < lowerBound || currentWeight > upperBound) {
                    sendSMS(context, phoneNumber, "Alert: Your weight is outside the maintenance range of " + lowerBound + " to " + upperBound + " lbs.");
                }
            }
        }
        // handles invalid data
        catch (NumberFormatException e) {
            Toast.makeText(context, "Invalid goal weight or buffer zone.", Toast.LENGTH_SHORT).show();
        }
    }

    private static void sendSMS(Context context, String phoneNumber, String message) {
        // Check if SMS permissions have been disabled
        String currentUser = SharedPrefsUtils.getCurrentUser(context);
        String smsPermissionDenied = SharedPrefsUtils.getUserData(context, currentUser, "smsPermissionDenied");

        if ("true".equals(smsPermissionDenied)) {
            Toast.makeText(context, "SMS notifications are disabled.", Toast.LENGTH_SHORT).show();
            return; // Exit without sending SMS
        }
        // If not disabled, send SMS
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS sent successfully to: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(context, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}
