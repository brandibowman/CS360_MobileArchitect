package com.cs360.project3_weighttracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "WeightTrackerPrefs";
    private static final String KEY_GOAL_WEIGHT = "goalWeight";

    private EditText goalWeightInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);

        String currentUser = SharedPrefsUtils.getCurrentUser(this);
        if (currentUser == null) {
            // No user is logged in, redirect to login screen
            Toast.makeText(this, "No user logged in. Redirecting to login.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
        NavigationUtils.setupBottomNavigation(bottomNavigationView, this);

        goalWeightInput = findViewById(R.id.goalWeightInput);
        Button updateGoalWeightButton = findViewById(R.id.updateGoalWeightButton);
        Button recordWeightButton = findViewById(R.id.recordWeightButton);

        String savedGoalWeight = SharedPrefsUtils.getGoalWeight(this, currentUser);
        if (savedGoalWeight != null && !savedGoalWeight.isEmpty()) {
            goalWeightInput.setText(savedGoalWeight);
        }

        // Update Goal Weight
        updateGoalWeightButton.setOnClickListener(v -> {
            String goalWeight = goalWeightInput.getText().toString();
            if (!goalWeight.isEmpty()) {
                SharedPrefsUtils.saveGoalWeight(this, currentUser, goalWeight);
                Toast.makeText(this, "Goal weight saved: " + goalWeight + " lbs", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter a valid goal weight.", Toast.LENGTH_SHORT).show();
            }
        });


        // Navigate to Record Weight
        recordWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RecordWeightActivity.class);
            startActivity(intent);
        });
    }

    private void loadGoalWeight() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedGoalWeight = preferences.getString(KEY_GOAL_WEIGHT, null);
        if (savedGoalWeight != null) {
            goalWeightInput.setText(savedGoalWeight);
        }
    }
}
