package com.cs360.project3_weighttracker;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NavigationUtils {

    public static void setupBottomNavigation(BottomNavigationView bottomNavigationView, AppCompatActivity activity) {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                if (!(activity instanceof MainActivity)) {
                    Intent homeIntent = new Intent(activity, MainActivity.class);
                    activity.startActivity(homeIntent);
                }
                return true;
            }

            if (itemId == R.id.nav_history) {
                if (!(activity instanceof DataDisplayActivity)) {
                    Intent dataIntent = new Intent(activity, DataDisplayActivity.class);
                    activity.startActivity(dataIntent);
                }
                return true;
            }

            if (itemId == R.id.nav_sms) {
                if (!(activity instanceof SmsPermissionActivity)) {
                    Intent smsIntent = new Intent(activity, SmsPermissionActivity.class);
                    activity.startActivity(smsIntent);
                }
                return true;
            }

            return false;
        });
    }
}
