package com.cs360.project3_weighttracker;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class RecordWeightActivity extends AppCompatActivity {

    private EditText dateInput;
    private EditText weightInput;

    private final Calendar calendar = Calendar.getInstance();
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.record_weight_screen);

        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        Button datePickerButton = findViewById(R.id.datePickerButton);
        Button saveWeightButton = findViewById(R.id.saveWeightButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        dbHelper = new DatabaseHelper(this);

        // Set current date
        updateDateField(calendar);

        // Date picker functionality
        datePickerButton.setOnClickListener(v -> showDatePicker());

        // Save weight
        saveWeightButton.setOnClickListener(v -> saveWeight());

        // Cancel button functionality
        cancelButton.setOnClickListener(v -> finish());
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                RecordWeightActivity.this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    updateDateField(calendar);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void updateDateField(Calendar calendar) {
        String selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
        dateInput.setText(selectedDate);
    }

    private void saveWeight() {
        String recordedWeight = weightInput.getText().toString();
        String recordedDate = dateInput.getText().toString();

        if (recordedWeight.isEmpty()) {
            Toast.makeText(this, "Please enter your weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save weight entry in the database
        saveWeightEntry(recordedDate, recordedWeight);

        // Parse weight as a double and check goals
        try {
            double currentWeight = Double.parseDouble(recordedWeight); // Convert weight to double
            GoalChecker.checkAndNotify(this, currentWeight); // Notify user based on goal logic
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight format.", Toast.LENGTH_SHORT).show();
        }

        Toast.makeText(this, "Weight saved: " + recordedWeight + " lbs", Toast.LENGTH_SHORT).show();
        finish(); // Close the activity
    }


    private void saveWeightEntry(String date, String weight) {
        String currentUser = SharedPrefsUtils.getCurrentUser(this);
        if (currentUser == null) {
            Toast.makeText(this, "No user logged in. Please log in first.", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, currentUser); // Save the username
        values.put(DatabaseHelper.COLUMN_DATE, date);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);

        // Insert or replace the weight for the same date and user
        long result = db.insertWithOnConflict(
                DatabaseHelper.TABLE_WEIGHTS,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE // Replaces the entry if the date exists for the same user
        );

        if (result != -1) {
            Toast.makeText(this, "Weight saved successfully for user: " + currentUser, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save weight.", Toast.LENGTH_SHORT).show();
        }
    }
}
