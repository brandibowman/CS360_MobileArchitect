package com.cs360.project3_weighttracker;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefsUtils {

    private static final String PREFS_NAME = "WeightTrackerPrefs";

    // Save the current logged-in user
    public static void saveCurrentUser(Context context, String username) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("current_user", username);
        editor.apply();
    }

    // Retrieve the current logged-in user
    public static String getCurrentUser(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getString("current_user", null);
    }

    // Log out the current user
    public static void logoutUser(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("current_user");
        editor.apply();
    }

    // Save user-specific data
    public static void saveUserData(Context context, String username, String dataKey, String dataValue) {
        SharedPreferences preferences = context.getSharedPreferences("UserData_" + username, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(dataKey, dataValue);
        editor.apply();
    }

    // Retrieve user-specific data
    public static String getUserData(Context context, String username, String dataKey) {
        SharedPreferences preferences = context.getSharedPreferences("UserData_" + username, Context.MODE_PRIVATE);
        return preferences.getString(dataKey, "");
    }

    // Save goal weight
    public static void saveGoalWeight(Context context, String username, String goalWeight) {
        SharedPreferences preferences = context.getSharedPreferences("UserData_" + username, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("goalWeight", goalWeight);
        editor.apply();
    }

    // Retrieve goal weight
    public static String getGoalWeight(Context context, String username) {
        SharedPreferences preferences = context.getSharedPreferences("UserData_" + username, Context.MODE_PRIVATE);
        return preferences.getString("goalWeight", "");
    }

    // Save recipient phone number
    public static void saveRecipientPhoneNumber(Context context, String phoneNumber) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("recipientPhoneNumber", phoneNumber);
        editor.apply();
    }

    // Retrieve recipient phone number
    public static String getRecipientPhoneNumber(Context context, String username) {
        SharedPreferences preferences = context.getSharedPreferences("UserData_" + username, Context.MODE_PRIVATE);
        return preferences.getString("phoneNumber", ""); // Default to empty string if not set
    }

    // Save goal type
    public static void saveGoalType(Context context, String goalType) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("goalType", goalType);
        editor.apply();
    }

    // Retrieve goal type
    public static String getGoalType(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getString("goalType", "");
    }

    // Save buffer zone
    public static void saveBufferZone(Context context, String bufferZone) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("bufferZone", bufferZone);
        editor.apply();
    }

    // Retrieve buffer zone
    public static String getBufferZone(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getString("bufferZone", "");
    }
}
