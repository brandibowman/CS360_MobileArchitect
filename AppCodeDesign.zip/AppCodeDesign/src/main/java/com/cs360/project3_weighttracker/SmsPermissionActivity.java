package com.cs360.project3_weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private TextView permissionStatusText;
    private EditText phoneNumberInput;
    private EditText bufferZoneInput;
    private LinearLayout bufferZoneLayout;
    private Button enableNotificationsButton;
    private Button disableNotificationsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permission_screen);

        // Get the current user
        String currentUser = SharedPrefsUtils.getCurrentUser(this);
        if (currentUser == null) {
            Toast.makeText(this, "No user logged in. Redirecting to login.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // Initialize UI elements
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        permissionStatusText = findViewById(R.id.smsPermissionDescription);
        bufferZoneInput = findViewById(R.id.bufferZoneInput);
        bufferZoneLayout = findViewById(R.id.bufferZoneLayout);
        enableNotificationsButton = findViewById(R.id.enableSmsPermissionButton);
        disableNotificationsButton = findViewById(R.id.disableSmsPermissionButton);

        Button savePhoneNumberButton = findViewById(R.id.savePhoneNumberButton);
        Button saveGoalButton = findViewById(R.id.saveGoalButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        RadioGroup goalTypeGroup = findViewById(R.id.goalRadioGroup);

        // Load user-specific data
        loadUserData(currentUser);

        // Set up bottom navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_sms);
        NavigationUtils.setupBottomNavigation(bottomNavigationView, this);

        // Save phone number on button click
        savePhoneNumberButton.setOnClickListener(v -> {
            String phoneNumber = phoneNumberInput.getText().toString();
            if (!phoneNumber.isEmpty()) {
                SharedPrefsUtils.saveUserData(this, currentUser, "phoneNumber", phoneNumber);
                Toast.makeText(this, "Phone number saved: " + phoneNumber, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        saveGoalButton.setVisibility(View.GONE);

        // Listen for changes in the goal type selection and save the goal type
        goalTypeGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String goalType = "";

            if (checkedId == R.id.radioWeightLoss) {
                goalType = "Weight Loss";
                bufferZoneLayout.setVisibility(View.GONE);
                saveGoalButton.setVisibility(View.GONE);
            } else if (checkedId == R.id.radioWeightGain) {
                goalType = "Weight Gain";
                bufferZoneLayout.setVisibility(View.GONE);
                saveGoalButton.setVisibility(View.GONE);
            } else if (checkedId == R.id.radioMaintainWeight) {
                goalType = "Maintain Weight";
                bufferZoneLayout.setVisibility(View.VISIBLE);
                saveGoalButton.setVisibility(View.VISIBLE);
            }

            if (!goalType.isEmpty()) {
                SharedPrefsUtils.saveUserData(this, currentUser, "goalType", goalType);
                Toast.makeText(this, "Goal type saved: " + goalType, Toast.LENGTH_SHORT).show();
            }
        });

        // Save buffer zone on button click
        saveGoalButton.setOnClickListener(v -> {
            String bufferZoneValue = bufferZoneInput.getText().toString();
            if (!bufferZoneValue.isEmpty()) {
                SharedPrefsUtils.saveUserData(this, currentUser, "bufferZone", bufferZoneValue);
                Toast.makeText(this, "Buffer zone saved: " + bufferZoneValue + " lbs", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter a valid buffer zone.", Toast.LENGTH_SHORT).show();
            }
        });

        // Enable notifications button functionality
        enableNotificationsButton.setOnClickListener(v -> {
            SharedPrefsUtils.saveUserData(this, currentUser, "smsPermissionDenied", "false");
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE
                );
            }
            updatePermissionStatus();
        });

        // Disable notifications button functionality
        disableNotificationsButton.setOnClickListener(v -> {
            SharedPrefsUtils.saveUserData(this, currentUser, "smsPermissionDenied", "true");
            Toast.makeText(this, "SMS notifications disabled.", Toast.LENGTH_SHORT).show();
            updatePermissionStatus();
        });

        // Logout button functionality
        logoutButton.setOnClickListener(v -> {
            SharedPrefsUtils.logoutUser(this);
            Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // Update initial permission status
        updatePermissionStatus();
    }

    private void loadUserData(String username) {
        String savedPhoneNumber = SharedPrefsUtils.getUserData(this, username, "phoneNumber");
        String savedBufferZone = SharedPrefsUtils.getUserData(this, username, "bufferZone");
        String savedGoalType = SharedPrefsUtils.getUserData(this, username, "goalType");

        if (savedPhoneNumber != null) {
            phoneNumberInput.setText(savedPhoneNumber);
        }

        if (savedBufferZone != null) {
            bufferZoneInput.setText(savedBufferZone);
        }

        if (savedGoalType != null) {
            if (savedGoalType.equals("Weight Loss")) {
                ((RadioGroup) findViewById(R.id.goalRadioGroup)).check(R.id.radioWeightLoss);
                bufferZoneLayout.setVisibility(View.GONE);
            } else if (savedGoalType.equals("Weight Gain")) {
                ((RadioGroup) findViewById(R.id.goalRadioGroup)).check(R.id.radioWeightGain);
                bufferZoneLayout.setVisibility(View.GONE);
            } else if (savedGoalType.equals("Maintain Weight")) {
                ((RadioGroup) findViewById(R.id.goalRadioGroup)).check(R.id.radioMaintainWeight);
                bufferZoneLayout.setVisibility(View.VISIBLE);
            }
        }
    }
    // dynamic button color change based on what is disabled and enabled
    private void updateButtonAppearance(Button button) {
        if (button.isEnabled()) {
            button.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.colorEnabled));
        } else {
            button.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.colorDisabled));
        }
    }

    private void updatePermissionStatus() {
        String currentUser = SharedPrefsUtils.getCurrentUser(this);
        String smsPermissionDenied = SharedPrefsUtils.getUserData(this, currentUser, "smsPermissionDenied");

        if (currentUser == null) {
            permissionStatusText.setText("No user logged in");
            enableNotificationsButton.setEnabled(false);
            disableNotificationsButton.setEnabled(false);
        } else if ("true".equals(smsPermissionDenied)) {
            permissionStatusText.setText("Notifications Disabled");
            enableNotificationsButton.setEnabled(true);
            disableNotificationsButton.setEnabled(false);
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            permissionStatusText.setText("SMS Permission: Granted");
            enableNotificationsButton.setEnabled(false);
            disableNotificationsButton.setEnabled(true);
        } else {
            permissionStatusText.setText("SMS Permission: Not Granted");
            enableNotificationsButton.setEnabled(true);
            disableNotificationsButton.setEnabled(false);
        }

        // Update button appearances
        updateButtonAppearance(enableNotificationsButton);
        updateButtonAppearance(disableNotificationsButton);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
            updatePermissionStatus();
        }
    }
}
